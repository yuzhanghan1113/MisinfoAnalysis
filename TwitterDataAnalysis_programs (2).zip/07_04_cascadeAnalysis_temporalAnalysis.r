library(tsfeatures)
library(data.table)
library(argparse)
library(urca)
library(pracma)

options(max.print = 999999)
options(error=traceback)

absFilename_output <- "D:/vmwareSharedFolder/TwitterDataAnalysis/results/analysis/temporal_retweets.csv"


df_output <- data.frame()

index_row <- 1

rootTweetIdStr <- "1287105426283274241"

df_output[index_row, "rootTweetIdStr"] <- rootTweetIdStr

list_absFilenames_input <- c("D:/vmwareSharedFolder/TwitterDataAnalysis/results/timeSeries/preprocessed/retweets/timeSeries_retweets_preprocessed_rootTweetID=1287105426283274241.csv")

for (absFilename_input in list_absFilenames_input) {
  
  print("absFilename_input:")
  print(absFilename_input)
  
  df_input <-
    data.frame(fread(
      absFilename_input,
      # nrows = 50000,
      sep = ",",
      header = TRUE,
      # select = vector_attributesToLoad_rereports,
      colClasses = c("character")
    ))
  
  print("nrow(df_input):")
  print(nrow(df_input))
  # print(head(df_input, n=5))
  #print(df_input[1, df_input$retweetAge_sec])
  
  vector_features <- colnames(df_input)
  vector_features <- vector_features[vector_features != "rootTweetIdStr"]
  df_input[, vector_features] <- sapply(df_input[, vector_features], as.numeric)
  # print(head(df_input, n=5))
  
  for (feature_toMeasure in vector_features) {
    
    print("rootTweetIdStr:")
    print(rootTweetIdStr)
    print("feature_toMeasure:")
    print(feature_toMeasure)
    print("length(df_input[, feature_toMeasure]):")
    print(length(df_input[, feature_toMeasure]))
    print("length(unique(df_input[, feature_toMeasure])):")
    print(length(unique(df_input[, feature_toMeasure])))
    
    df_output[index_row, "rootTweetIdStr"] <- rootTweetIdStr
    df_output[index_row, "feature"] <- feature_toMeasure
    
    
    vector_timeSeries_original <- df_input[, feature_toMeasure]
    print("length(vector_timeSeries_original):")
    print(length(vector_timeSeries_original))
    vector_timeSeries_nonNA <- vector_timeSeries_original[!is.na(vector_timeSeries_original)]
    print("length(vector_timeSeries_nonNA):")
    print(length(vector_timeSeries_nonNA))
    # print("vector_timeSeries_nonNA:")
    # print(vector_timeSeries_nonNA)
    
    print("entropy:")
    if (length(vector_timeSeries_nonNA) == 0 || var(vector_timeSeries_nonNA) == 0) {
      df_output[index_row, "entropy"] <- NA
    }
    else {
      result <- entropy(vector_timeSeries_nonNA)
      df_output[index_row, "entropy"] <- result
    }
    
    print("stability:")
    result <- stability(vector_timeSeries_original)
    df_output[index_row, "stability"] <- result
    
    print("lumpiness:")
    result <- lumpiness(vector_timeSeries_original)
    df_output[index_row, "lumpiness"] <- result
    
    print("max_level_shift:")
    result <- max_level_shift(vector_timeSeries_original)
    df_output[index_row, "maxLevelShift_maxLevelShift"] <- result["max_level_shift"]
    df_output[index_row, "maxLevelShift_timeLevelShift"] <- result["time_level_shift"] 
    
    print("max_var_shift:")
    result <- max_var_shift(vector_timeSeries_original)
    df_output[index_row, "maxVarShift_maxVarShift"] <- result["max_var_shift"]
    df_output[index_row, "maxVarShift_timeVarShift"] <- result["time_var_shift"] 
    
    # max_kl_shift(vector_timeSeries_original)
    
    print("crossing_points:")
    result <- crossing_points(vector_timeSeries_original)
    df_output[index_row, "crossingPoints"] <- result
    
    print("flat_spots:")
    result <- flat_spots(vector_timeSeries_original)
    df_output[index_row, "flatSpots"] <- result
    
    
    # hurst(vector_timeSeries_original)
    # hurst(vector_timeSeries_nonNA)
    # result <- hurstexp(vector_timeSeries_original)
    # result <- hurstexp(vector_timeSeries_nonNA)
    # print(result)
    
    # result <- unitroot_kpss(df_input[, feature_toMeasure])
    
    print("ur.kpss:")
    result <- ur.kpss(vector_timeSeries_original)
    df_output[index_row, "KPSS_statistic"] <- result@teststat
    df_output[index_row, "KPSS_LT10pct"] <- ifelse (result@teststat > result@cval[1], 1, 0)
    df_output[index_row, "KPSS_LT5pct"] <- ifelse (result@teststat > result@cval[2], 1, 0)
    df_output[index_row, "KPSS_LT2p5pct"] <- ifelse (result@teststat > result@cval[3], 1, 0)
    df_output[index_row, "KPSS_LT1pct"] <- ifelse (result@teststat > result@cval[4], 1, 0)
    
    # result <- unitroot_pp(df_input[, feature_toMeasure])
    # print(result)
    # result <- ur.pp(df_input[, feature_toMeasure], type="Z-tau")
    # summary(result)
    # result@teststat
    # result@cval
    
    print("stl_features:")
    result <- stl_features(vector_timeSeries_original)
    df_output[index_row, "stl_nperiods"] <- result[["nperiods"]]
    df_output[index_row, "stl_seasonalPeriod"] <- result[["seasonal_period"]]
    df_output[index_row, "stl_trend"] <- result[["trend"]]
    df_output[index_row, "stl_spike"] <- result[["spike"]]
    df_output[index_row, "stl_linearity"] <- result[["linearity"]]
    df_output[index_row, "stl_curvature"] <- result[["curvature"]]
    df_output[index_row, "stl_eacf1"] <- result[["e_acf1"]]
    df_output[index_row, "stl_eacf10"] <- result[["e_acf10"]]
    
    print("nonlinearity:")
    result <- nonlinearity(vector_timeSeries_original)
    df_output[index_row, "nonlinearity"] <- result
    
    # sampen_first(df_input[, feature_toMeasure])
    # sampenc(df_input[, feature_toMeasure], M = 5, r = 0.3)
    
    print("std1st_der:")
    result <- std1st_der(vector_timeSeries_original)
    df_output[index_row, "std1stDer"] <- result
    
    print("histogram_mode:")
    result <- histogram_mode(vector_timeSeries_original, numBins = 10)
    df_output[index_row, "histogramMode"] <- result
    
    # fluctanal_prop_r1(df_input[, feature_toMeasure])
    
    index_row <- index_row + 1
  }
}  
  
df_output <- sapply(df_output, as.character)

print("absFilename_output:")
print(absFilename_output)

write.table(
  df_output,
  absFilename_output,
  sep = ",",
  row.names = FALSE,
  col.names = TRUE,
  quote = TRUE
)

