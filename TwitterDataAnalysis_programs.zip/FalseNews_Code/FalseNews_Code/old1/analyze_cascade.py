from settings import *

def calc_depth(G,G_root):
    depth=nx.eccentricity(G,v=G_root)
    return depth

def calc_structural_viralty(G,size):
    if size==1:
        return None ##virality is not defined for cascades of size 1,
    sv=nx.average_shortest_path_length(G)  #Note: this is very time-consuming for larger cascades
    return sv

"""   
def calc_structural_viralty(G,size):
    if size==1:
        return None ##virality is not defined for cascades of size 1,
    sv = -1
    return sv
"""

def calc_size(G):
    num_nodes=G.number_of_nodes()
    return num_nodes



def get_metadata(cascade_graph, absFilename_output_temporal:str, absFilename_output_figure:str):

    #tid_root = 1239336564334960642
    tid_root = -1
    for n in cascade_graph.nodes(data=True):
        #print(n)
        if "is_root" in n[1] and n[1]["is_root"] == True:
            tid_root = n[0]
    print("tid_root:")
    print(tid_root)

    cascade_graph=cascade_graph.to_undirected()
    
    
    #print("cascade_graph:")
    print("cascade_graph.number_of_nodes() 1:")
    print(cascade_graph.number_of_nodes())
    
    print("nx.number_connected_components(cascade_graph):")
    print(nx.number_connected_components(cascade_graph))
    
    list_componentsToRemove = []
    for c in nx.connected_components(cascade_graph):
        #print("component:")
        #print(c)
        if tid_root not in c:
            list_componentsToRemove.extend(c)
            #print("not in")
            
    #print("list_componentsToRemove:")
    #print(list_componentsToRemove)
    
    for n in list_componentsToRemove:
       cascade_graph.remove_node(n) 


    
    
    #for n in cascade_graph.nodes(data=True):       
    #    #print(type(n))
    #    print(n)
    
    #list_nodes = cascade_graph.nodes(data=True)
    #print(len(list_nodes))
    #for n in cascade_graph.nodes(data=True):
    #    print(n[1]["is_root"])
    

    print("cascade_graph.number_of_nodes() 2:")
    print(cascade_graph.number_of_nodes())
    
    

    
    
    metadata={}
    node2date=nx.get_node_attributes(cascade_graph,'date')
    #root=[n for n in cascade_graph if cascade_graph.node[n]['is_root']==True][0]
    root = None
    for n in cascade_graph.nodes(data=True):
        #print(n)
        if "is_root" in n[1] and n[1]["is_root"] == True:
            root = n
    print("root:")
    print(root)
    #root_date=node2date[root]
    root_date=node2date[root[0]]
    print("root_date")
    print(root_date)
    
    
    #nx.draw_networkx(G=cascade_graph, with_labels=False, node_size=2)
    nx.draw_spring(G=cascade_graph, with_labels=False, node_size=2)
    #plt.draw()  # pyplot draw()
    #plt.show()
    
    plt.savefig(absFilename_output_figure, bbox_inches="tight", format="png")
    
    
    #for n in cascade_graph.nbunch_iter(root[0]):
    #    print("nbunch_iter n:")
    #    print(n)
    
    ##Static measures
    #depth=calc_depth(cascade_graph,root)
    depth=calc_depth(cascade_graph,root[0])
    size=calc_size(cascade_graph)
    virality=calc_structural_viralty(cascade_graph, size)
    #virality=-1
    metadata['root_tid']=root
    metadata['start_date']=root_date
    metadata['size']=size
    metadata['depth']=depth
    metadata['virality']=virality
    metadata['unique_users']=size #since each user can only retweet once

    ##Dynamic measures
    metadata['depth2time']={}
    metadata['depth2uu']={}
    metadata['depth2breadth']={}
    metadata['uu2time']={}
    done_nodes=[]
    done_uids=set([])
    for dp in range(depth):
        current_dp=dp+1
        #current_subgraph=nx.ego_graph(cascade_graph, root, radius=current_dp)
        current_subgraph=nx.ego_graph(cascade_graph, root[0], radius=current_dp)

        current_sb_nodes=current_subgraph.nodes()
        node2date=nx.get_node_attributes(current_subgraph,'date')
        node_dates=node2date.items()
        node_dates=[(n,d) for n,d in node_dates if n not in done_nodes]
        if len(node_dates)==0:
            break
        current_depth_nodes=[n for n,d in node_dates]
        node_dates.sort(key=lambda x:x[1])
        depth_date=node_dates[0][1]
        time_elapsed=(depth_date-root_date).total_seconds()
        metadata['depth2time'][current_dp]=time_elapsed
        nodes=current_subgraph.nodes()
        for user in nodes:
            if user not in done_uids:
                done_uids.add(user)
        unique_users=len(nodes)
        metadata['depth2uu'][current_dp]=unique_users
        current_breadth=len(current_depth_nodes)
        metadata['depth2breadth'][current_dp]=current_breadth
        done_nodes=current_sb_nodes

    current_users=[]
    current_uu2time={}
    node_dates=node2date.items()
    #node_dates.sort(key=lambda x:x[1])
    node_dates = sorted(node_dates, key=lambda x:x[1])
    
    for node,date in node_dates:
        current_users.append(node)
        u_current_users=set(current_users)
        num_unique_users=len(u_current_users)
        uu_time=current_uu2time.get(num_unique_users)
        time_elapsed=(date-root_date).total_seconds()
        if uu_time==None:
            current_uu2time[num_unique_users]=time_elapsed
            metadata['uu2time'][num_unique_users]=time_elapsed

    breadths=metadata['depth2breadth'].values()
    maxbreadth=1 if len(breadths)==0 else max(breadths)
    metadata['max_breadth']=maxbreadth

    ##User stats
    metadata['verified_list']=[]
    metadata['num_followers_list']=[]
    metadata['num_followees_list']=[]
    metadata['accountage_list']=[]
    metadata['engagement_list']=[]
    node2verified=nx.get_node_attributes(cascade_graph,'verified')
    node2followers=nx.get_node_attributes(cascade_graph,'followers')
    node2followees=nx.get_node_attributes(cascade_graph,'followees')
    node2accage=nx.get_node_attributes(cascade_graph,'account_age')
    node2engagement=nx.get_node_attributes(cascade_graph,'engagement')
    for n in cascade_graph.nodes():
        metadata['num_followers_list'].append(node2followers[n])
        metadata['num_followees_list'].append(node2followees[n])
        metadata['accountage_list'].append(node2accage[n])
        metadata['engagement_list'].append(node2engagement[n])
        metadata['verified_list'].append(node2verified[n])
    ###
    
    #list_nodes = nx.single_source_shortest_path_length(cascade_graph, root[0], 3)
    #print("list_nodes[2]:")
    #print(list_nodes[2])
    
    datetime_root = root[1]["date"]
    print("datetime_root:")
    print(datetime_root)
      
    #print("cascade_graph.nodes[1250849915217096704][\"date\"]:")
    #print(cascade_graph.nodes[1250849915217096704]["date"])
    
    df_output_temporal = pd.DataFrame()
    
    list_cascadeAge_min = [n for n in range(0, 26*60+10, 10)]             
    list_cascadeAge_min += [n for n in range(0, 7*24*60+60, 60)]
    list_cascadeAge_min = sorted(list(set(list_cascadeAge_min)))
    
    print(list_cascadeAge_min)
    print(len(list_cascadeAge_min))
    
    index_row = 0
    for cascadeAge_min in list_cascadeAge_min:
    
        print("cascadeAge_min:")
        print(cascadeAge_min)
        
        df_output_temporal.loc[index_row, "cascadeAge_min"] = str(cascadeAge_min)
    
    
        list_nodesAtr = cascade_graph.nodes(data="date")
        #print("list_nodesAtr:")
        #print(list_nodesAtr)
        print(len(list_nodesAtr))
        list_nodesAtr_subgraph = [n for n in list_nodesAtr if (n[1]-datetime_root).total_seconds()/60 <= cascadeAge_min]
        print("list_nodesAtr_subgraph:")
        #print(list_nodesAtr_subgraph)
        print(len(list_nodesAtr_subgraph))
        list_nodes_subgraph = [n[0] for n in list_nodesAtr_subgraph]
        print(len(list_nodes_subgraph))
        subgraph = cascade_graph.subgraph(list_nodes_subgraph)
        
        list_temp = subgraph.nodes()
        print(len(list_temp))
        
        
        size_subgraph = calc_size(subgraph)  
        print("size_subgraph:")
        print(size_subgraph) 
        
        depth_subgraph = calc_depth(subgraph,root[0])
        print("depth_subgraph:")
        print(depth_subgraph) 
        
        virality_subgraph = calc_structural_viralty(subgraph, size_subgraph)
        print("virality_subgraph:")
        print(virality_subgraph)
        
        df_output_temporal.loc[index_row, "cascadeSize"] = str(size_subgraph)
        df_output_temporal.loc[index_row, "cascadeDepth"] = str(depth_subgraph)
        df_output_temporal.loc[index_row, "cascadeVirality"] = str(virality_subgraph)


        list_attributesToRecord = ["followers", "followees", "account_age", "engagement"]
        
        for str_attributeName in list_attributesToRecord:
        
            print("str_attributeName:")
            print(str_attributeName)
        
            list_nodes_attribute = subgraph.nodes(data=str_attributeName)
            #print(list_nodes_attribute)
            
            mean_attribute = np.mean([n[1] for n in list_nodes_attribute])
            print("mean_attribute:")
            print(mean_attribute)        
            df_output_temporal.loc[index_row, "mean_" + str_attributeName] = str(mean_attribute)
            
            median_attribute = np.median([n[1] for n in list_nodes_attribute])
            print("median_attribute:")
            print(median_attribute)        
            df_output_temporal.loc[index_row, "median_" + str_attributeName] = str(median_attribute)
        
        
        #if index_row%100 == 0:
        #    df_output_temporal.to_csv(absFilename_output_temporal, index=False)
        df_output_temporal.to_csv(absFilename_output_temporal, index=False)
        
        index_row += 1

    df_output_temporal.to_csv(absFilename_output_temporal, index=False)
    
    
    
    return metadata