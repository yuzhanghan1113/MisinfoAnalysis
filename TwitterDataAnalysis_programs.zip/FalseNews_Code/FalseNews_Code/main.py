from settings import *
import analyze_cascade

#tweetID_root = "1262482651333738500"
#tweetID_root = "1247287993095897088"

#raw_data_file="./data/raw_data_anon_rootTweetID=" + tweetID_root + ".csv"
#regression_file='./data/regression_data_anon.txt'
#metadata_file="./data/metadata_anon_rootTweetID=" + tweetID_root + ".txt"
#emotions_file='./data/emotions_anon.csv'
#topics_file='./data/topics_anon.csv'



def convert_raw_data_to_metadata(raw_data_file:str, metadata_file:str, absFilename_output_temporal:str, absFilename_output_figure:str, toVisualize:str, toComputeViralityOfFullCascade:str):
    print("Converting raw data to metadata...")
    #with open(raw_data_file,'rb') as f:
    with open(raw_data_file,'r') as f:
        reader=csv.reader(f)
        next(reader, None) #skippingthe header
        reader = sorted(reader, key=lambda row: (row[2],row[5])) #Sort by cascade id
        row_num=0
        last_cascade_id=None
        #resetting files...
        fout=open(metadata_file,'w')
        fout.close()
        for row in reader:
        
            #print("row:")
            #print(row)
        
            tid=int(row[0])
            veracity=str(row[1])
            cascade_id=int(row[2])
            rumor_id=str(row[3])
            rumor_category=str(row[4])
            parent_tid=int(row[5])
            tweet_date=parser.parse(row[6])
            user_account_age=eval(row[7])
            user_verified=eval(row[8])
            user_followers=eval(row[9])
            user_followees=eval(row[10])
            user_engagement=float(row[11])
            cascade_root_tid=eval(row[12])
            was_retweeted=int(row[13])
            
            #print(tid)
            #print(user_engagement)
            
            ##
            if cascade_id!=last_cascade_id: #New cascade
                ###Extracting metadata from the previous cascade graph
                if last_cascade_id!=None:
                    mt=analyze_cascade.get_metadata(graph, absFilename_output_temporal=absFilename_output_temporal, absFilename_output_figure=absFilename_output_figure, toVisualize=toVisualize, toComputeViralityOfFullCascade=toComputeViralityOfFullCascade)
                    metadata.update(mt)
                    fout=open(metadata_file,'a')
                    fout.write(repr((last_cascade_id,metadata))+'\n')
                    fout.close()
                ###Creating a new graph using networkx to extract metadata
                metadata={}
                metadata['veracity']=veracity
                metadata['rumor_id']=rumor_id
                metadata['rumor_category']=rumor_category
                graph=nx.DiGraph()
                last_cascade_id=cascade_id
                last_tid=tid
            graph.add_node(tid,date=tweet_date,is_root=True if parent_tid==-1 else False,followers=user_followers, followees=user_followees,
                       verified=user_verified,account_age=user_account_age,engagement=user_engagement)
            if parent_tid!=-1: #add an edge between parent node and child node if one exists
                graph.add_edge(parent_tid,tid)
            if row_num%10000==0:
                print(str(row_num) + "rows read")
            row_num+=1
            
    #Saving the last remaining cascade
    mt=analyze_cascade.get_metadata(graph, absFilename_output_temporal=absFilename_output_temporal, absFilename_output_figure=absFilename_output_figure, toVisualize=toVisualize, toComputeViralityOfFullCascade=toComputeViralityOfFullCascade)
    metadata.update(mt)
    fout=open(metadata_file,'a')
    fout.write(repr((last_cascade_id,metadata))+'\n')
    fout.close()
    
    print("finished")
    
def main(argv):
    random.seed(1113)
    

    # pd.set_option('display.height', 1000)
    pd.set_option('display.max_rows', 1000)
    pd.set_option('display.max_columns', 1000)
    # pd.set_option('display.width', 170)
    pd.set_option('display.float_format', lambda x: '%.0f' % x)
    
    opts, args = getopt.getopt(argv, '', ["path_base=", "date_retrieval=", "tweetID_root=", "toVisualize=", "toComputeViralityOfFullCascade="])
    
    print(opts)
    
    toVisualize = "True"
    toComputeViralityOfFullCascade = "False"

    for opt, arg in opts:
        if opt == '--path_base':
            path_base = arg
        elif opt == '--date_retrieval':
            date_retrieval = arg
        elif opt == '--tweetID_root':
            tweetID_root = arg
        elif opt == '--toVisualize':
            toVisualize = arg
        elif opt == '--toComputeViralityOfFullCascade':
            toComputeViralityOfFullCascade = arg
            
    absFilename_input_raw_data_file = path_base + "raw" + os.path.sep + "raw_data_anon_rootTweetID=" + tweetID_root + ".csv"
    
    if not os.path.exists(os.path.dirname(absFilename_input_raw_data_file)):
        os.makedirs(os.path.dirname(absFilename_input_raw_data_file))
        
    print("absFilename_input_raw_data_file:")
    print(absFilename_input_raw_data_file)
    
    absFilename_output_metadata_file = path_base + "meta" + os.path.sep + "metadata_anon_rootTweetID=" + tweetID_root + ".txt"    
    
    if not os.path.exists(os.path.dirname(absFilename_output_metadata_file)):
        os.makedirs(os.path.dirname(absFilename_output_metadata_file))
        
    print("absFilename_output_metadata_file:")
    print(absFilename_output_metadata_file)
    
    absFilename_output_temporal = path_base + "temporal" + os.path.sep + "temporalCharacteristics_rootTweetID=" + tweetID_root + ".csv"
    
    if not os.path.exists(os.path.dirname(absFilename_output_temporal)):
        os.makedirs(os.path.dirname(absFilename_output_temporal))
              
    print("absFilename_output_temporal:")
    print(absFilename_output_temporal)
    
    absFilename_output_figure = path_base + "figures" + os.path.sep + "cascade_rootTweetID=" + tweetID_root + ".png"
    
    if not os.path.exists(os.path.dirname(absFilename_output_figure)):
        os.makedirs(os.path.dirname(absFilename_output_figure))
    
    print("absFilename_output_figure:")
    print(absFilename_output_figure)
            
    convert_raw_data_to_metadata(raw_data_file=absFilename_input_raw_data_file, metadata_file=absFilename_output_metadata_file, absFilename_output_temporal=absFilename_output_temporal, absFilename_output_figure=absFilename_output_figure, toVisualize=toVisualize, toComputeViralityOfFullCascade=toComputeViralityOfFullCascade)  ##Warning: This take a long time to run!
    #generate_figures()
    
if __name__ == "__main__":
    main(sys.argv[1:])